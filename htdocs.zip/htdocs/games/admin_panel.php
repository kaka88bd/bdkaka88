<?php
session_start();
include '../db.php';

// Admin check (you can update this as needed)
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    die("Access denied");
}

$result = $conn->query("
    SELECT ar.*, u.username 
    FROM aviator_results ar
    JOIN users u ON ar.user_id = u.id
    ORDER BY ar.timestamp DESC
");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Panel - Aviator Results</title>
  <style>
    body { background: #111; color: white; font-family: sans-serif; padding: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 8px; border: 1px solid #444; text-align: center; }
    th { background: #333; }
  </style>
</head>
<body>
  <h1>🎛️ Aviator Admin Panel</h1>
  <table>
    <tr>
      <th>ID</th>
      <th>User</th>
      <th>Bet</th>
      <th>Multiplier</th>
      <th>Won</th>
      <th>Time</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= $row['bet_amount'] ?>৳</td>
        <td><?= $row['multiplier'] ?>x</td>
        <td><?= $row['won_amount'] ?>৳</td>
        <td><?= $row['timestamp'] ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
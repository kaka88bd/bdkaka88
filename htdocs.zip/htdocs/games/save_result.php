<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$bet = floatval($_POST['bet']);
$multiplier = floatval($_POST['multiplier']);
$won = floatval($_POST['won']);

$conn->query("INSERT INTO aviator_results (user_id, bet_amount, multiplier, won_amount)
              VALUES ($user_id, $bet, $multiplier, $won)");

if ($won > 0) {
    $conn->query("UPDATE users SET balance = balance + $won WHERE id = $user_id");
} else {
    $conn->query("UPDATE users SET balance = balance - $bet WHERE id = $user_id");
}

$result = $conn->query("SELECT balance FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();
echo json_encode(["new_balance" => $user['balance']]);
?>
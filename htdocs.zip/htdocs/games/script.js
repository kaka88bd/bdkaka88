
let multiplier = 1.00;
let crashPoint = (Math.random() * 4.5 + 1).toFixed(2); // Between 1.00 and 5.50
let gameRunning = true;
let cashedOut = false;
let interval;
let gameHistory = [];
const display = document.getElementById("multiplierDisplay");
const cashoutBtn = document.getElementById("cashoutButton");
const flySound = document.getElementById("flySound");
const crashSound = document.getElementById("crashSound");
const cashoutSound = document.getElementById("cashoutSound");
const airplaneIcon = document.querySelector('.airplane-icon');
const historyDisplay = document.getElementById("gameHistory");

// Start sound and game loop
flySound.play();
interval = setInterval(() => {
    if (!gameRunning) return;

    multiplier += 0.01;
    multiplier = parseFloat(multiplier.toFixed(2));
    display.innerText = multiplier.toFixed(2) + "x";

    if (multiplier >= crashPoint || multiplier >= 5.50) {
        gameRunning = false;
        clearInterval(interval);
        flySound.pause();
        crashSound.play();

        // Animate crash effect
        airplaneIcon.classList.add('crashed');

        if (!cashedOut) {
            alert("Crashed at " + multiplier.toFixed(2) + "x! You lost.");
        }
        gameHistory.unshift("Crash at " + multiplier.toFixed(2) + "x");
        updateHistory();
    }
}, 100);

// Cash-out logic
cashoutBtn.addEventListener("click", () => {
    if (!gameRunning || cashedOut) return;
    cashedOut = true;
    gameRunning = false;
    clearInterval(interval);
    flySound.pause();
    cashoutSound.play();
    alert("Cashed out at " + multiplier.toFixed(2) + "x!");
    gameHistory.unshift("Cashed out at " + multiplier.toFixed(2) + "x");
    updateHistory();
});

function updateHistory() {
    historyDisplay.innerHTML = "<strong>Game History:</strong><br>" + gameHistory.slice(0, 5).join("<br>");
}

// Multiplayer simulation (names + random bet)
const playerNames = ["Alice", "Bob", "Charlie", "Dana", "Eve"];
const multiplayerInfo = playerNames.map(name => {
    const bet = (Math.random() * 100 + 10).toFixed(2);
    return name + ": $" + bet;
}).join(" | ");
display.insertAdjacentHTML("afterend", `<div style='font-size:14px; margin-top:4px;'>${multiplayerInfo}</div>`);

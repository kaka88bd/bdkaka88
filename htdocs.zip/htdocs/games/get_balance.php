<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$res = $conn->query("SELECT balance FROM users WHERE id = $user_id");
$row = $res->fetch_assoc();
echo json_encode(["balance" => $row['balance']]);
?>
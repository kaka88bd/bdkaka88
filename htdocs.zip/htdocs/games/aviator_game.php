<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT balance FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();
$balance = $user['balance'];
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
  <title>Aviator Crash Game</title>
  <style>
    body { background: #0f0f0f; color: white; font-family: sans-serif; text-align: center; }
    #multiplier { font-size: 60px; margin-top: 40px; color: #0f0; }
    .controls { margin: 20px; }
    input, button { padding: 10px; font-size: 16px; margin: 5px; }
  
    .animated-text {
      animation: pulse 0.5s infinite alternate ease-in-out;
    }
    @keyframes pulse {
      from { transform: scale(1); color: #0f0; }
      to { transform: scale(1.1); color: #ff0; }
    }
    
    #airplane {
      position: absolute;
      top: 100px;
      left: -100px;
      width: 100px;
      height: 40px;
      background-image: url('https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Airplane_silhouette.svg/1200px-Airplane_silhouette.svg.png');
      background-size: contain;
      background-repeat: no-repeat;
      animation: fly 6s linear infinite;
    }

    @keyframes fly {
      from { left: -150px; }
      to { left: 100%; }
    }

    .game-container {
      position: relative;
      height: 300px;
      overflow: hidden;
    }

    #multiplier {
      font-weight: bold;
      text-shadow: 0 0 10px #0f0, 0 0 20px #0f0;
    }
    </style>
    

</head>
<body>


<div class="airplane-container">
  <div class="airplane-icon">✈️</div>
</div>


  <div class="game-container"><div id="airplane"></div></div>
  <h1>🚀 Aviator Crash Game</h1>
  <h3>Balance: <span id="balance"><?= $balance ?></span>৳</h3>

  <div class="controls">
    <input type="number" id="bet" placeholder="Enter bet (5 - 1000)" min="5" max="1000">
    <button onclick="placeBet()">Place Bet</button>
    <button id="cashout" onclick="cashOut()" disabled>💰 Cash Out</button>
  </div>

  <div id="multiplier" class="animated-text">1.00x</div>
  <p id="status"></p>

  <script src="script.js"></script>

    <div class="hud">
        <div id="multiplierDisplay">1.00x</div>
        <button id="cashoutButton">Cash Out</button>
        <div id="gameHistory"></div>
    </div>

    <audio id="flySound" src="fly.mp3" loop></audio>
    <audio id="crashSound" src="crash.mp3"></audio>
    <audio id="cashoutSound" src="cashout.mp3"></audio>
    
</body>
</html>
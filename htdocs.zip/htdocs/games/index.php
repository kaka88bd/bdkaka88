<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: /login.php");
  exit;
}
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Aviator Game</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div id="balance">Balance: Loading...</div>
  <div id="multiplier">1.00x</div>
  <div>
    <label for="bet">Bet Amount (5৳ - 1000৳): </label>
    <input type="number" id="bet" min="5" max="1000" value="10">
  </div>
  <button id="cashOut">Cash Out</button>

  <script>
    const userId = <?php echo $user_id; ?>;
  </script>
  <script src="script.js"></script>
</body>
</html>